import Vue from 'vue'
import global from '~/util/global_util.js'

Vue.prototype.$global = global