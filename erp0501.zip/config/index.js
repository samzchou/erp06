module.exports = {
	// 服务器环境
	env:{
		server_url: 'http://localhost',
		HOST: '0.0.0.0',
		PORT: 80,
	},
}
