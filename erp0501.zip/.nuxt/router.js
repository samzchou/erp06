import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _4a969000 = () => interopDefault(import('..\\pages\\invoice\\index.vue' /* webpackChunkName: "pages_invoice_index" */))
const _6c39c482 = () => interopDefault(import('..\\pages\\invoice\\index\\index.vue' /* webpackChunkName: "pages_invoice_index_index" */))
const _bb9c2a4c = () => interopDefault(import('..\\pages\\invoice\\index\\collect.vue' /* webpackChunkName: "pages_invoice_index_collect" */))
const _35b95e93 = () => interopDefault(import('..\\pages\\invoice\\index\\finish.vue' /* webpackChunkName: "pages_invoice_index_finish" */))
const _1bbf6304 = () => interopDefault(import('..\\pages\\login\\index.vue' /* webpackChunkName: "pages_login_index" */))
const _4cf7140e = () => interopDefault(import('..\\pages\\finial\\invoice.vue' /* webpackChunkName: "pages_finial_invoice" */))
const _d1a598ce = () => interopDefault(import('..\\pages\\finial\\payin.vue' /* webpackChunkName: "pages_finial_payin" */))
const _c8eb6fec = () => interopDefault(import('..\\pages\\finial\\payout.vue' /* webpackChunkName: "pages_finial_payout" */))
const _6e77a564 = () => interopDefault(import('..\\pages\\meta\\crm.vue' /* webpackChunkName: "pages_meta_crm" */))
const _d7ba4842 = () => interopDefault(import('..\\pages\\meta\\product.vue' /* webpackChunkName: "pages_meta_product" */))
const _6f18b7ea = () => interopDefault(import('..\\pages\\meta\\user.vue' /* webpackChunkName: "pages_meta_user" */))
const _5dd15820 = () => interopDefault(import('..\\pages\\options\\flowState.vue' /* webpackChunkName: "pages_options_flowState" */))
const _ea6f937e = () => interopDefault(import('..\\pages\\options\\org.vue' /* webpackChunkName: "pages_options_org" */))
const _a45a0442 = () => interopDefault(import('..\\pages\\options\\payType.vue' /* webpackChunkName: "pages_options_payType" */))
const _898dfc9e = () => interopDefault(import('..\\pages\\options\\pos.vue' /* webpackChunkName: "pages_options_pos" */))
const _f54a2272 = () => interopDefault(import('..\\pages\\options\\ptype.vue' /* webpackChunkName: "pages_options_ptype" */))
const _729df9e9 = () => interopDefault(import('..\\pages\\options\\role.vue' /* webpackChunkName: "pages_options_role" */))
const _d7922742 = () => interopDefault(import('..\\pages\\options\\storeNo.vue' /* webpackChunkName: "pages_options_storeNo" */))
const _5a3206ad = () => interopDefault(import('..\\pages\\options\\type.vue' /* webpackChunkName: "pages_options_type" */))
const _19f0d21a = () => interopDefault(import('..\\pages\\order\\buy.vue' /* webpackChunkName: "pages_order_buy" */))
const _6f7203e8 = () => interopDefault(import('..\\pages\\order\\buy-list.vue' /* webpackChunkName: "pages_order_buy-list" */))
const _ca6970dc = () => interopDefault(import('..\\pages\\order\\deliver.vue' /* webpackChunkName: "pages_order_deliver" */))
const _b86cc4fe = () => interopDefault(import('..\\pages\\order\\import-buy.vue' /* webpackChunkName: "pages_order_import-buy" */))
const _f3ce7748 = () => interopDefault(import('..\\pages\\order\\import-sale.vue' /* webpackChunkName: "pages_order_import-sale" */))
const _b60eddf0 = () => interopDefault(import('..\\pages\\order\\order-row.vue' /* webpackChunkName: "pages_order_order-row" */))
const _310cb466 = () => interopDefault(import('..\\pages\\order\\pake-list.vue' /* webpackChunkName: "pages_order_pake-list" */))
const _5259b212 = () => interopDefault(import('..\\pages\\order\\plane-list.vue' /* webpackChunkName: "pages_order_plane-list" */))
const _1e99f92a = () => interopDefault(import('..\\pages\\order\\sale.vue' /* webpackChunkName: "pages_order_sale" */))
const _47e76c11 = () => interopDefault(import('..\\pages\\order\\sale-list.vue' /* webpackChunkName: "pages_order_sale-list" */))
const _093f6c58 = () => interopDefault(import('..\\pages\\produce\\on.vue' /* webpackChunkName: "pages_produce_on" */))
const _40c45bea = () => interopDefault(import('..\\pages\\store\\calc.vue' /* webpackChunkName: "pages_store_calc" */))
const _71061060 = () => interopDefault(import('..\\pages\\store\\calc-list.vue' /* webpackChunkName: "pages_store_calc-list" */))
const _3612abef = () => interopDefault(import('..\\pages\\store\\collocation.vue' /* webpackChunkName: "pages_store_collocation" */))
const _4f12674a = () => interopDefault(import('..\\pages\\store\\in.vue' /* webpackChunkName: "pages_store_in" */))
const _6485e194 = () => interopDefault(import('..\\pages\\store\\in-buy.vue' /* webpackChunkName: "pages_store_in-buy" */))
const _4635faae = () => interopDefault(import('..\\pages\\store\\in-sale.vue' /* webpackChunkName: "pages_store_in-sale" */))
const _f91870f0 = () => interopDefault(import('..\\pages\\store\\out.vue' /* webpackChunkName: "pages_store_out" */))
const _039ac9e0 = () => interopDefault(import('..\\pages\\store\\outsend.vue' /* webpackChunkName: "pages_store_outsend" */))
const _2391bca7 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

if (process.client) {
  if ('scrollRestoration' in window.history) {
    window.history.scrollRestoration = 'manual'

    // reset scrollRestoration to auto when leaving page, allowing page reload
    // and back-navigation from other pages to use the browser to restore the
    // scrolling position.
    window.addEventListener('beforeunload', () => {
      window.history.scrollRestoration = 'auto'
    })

    // Setting scrollRestoration to manual again when returning to this page.
    window.addEventListener('load', () => {
      window.history.scrollRestoration = 'manual'
    })
  }
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: decodeURI('/'),
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/invoice",
      component: _4a969000,
      children: [{
        path: "",
        component: _6c39c482,
        name: "invoice-index"
      }, {
        path: "collect",
        component: _bb9c2a4c,
        name: "invoice-index-collect"
      }, {
        path: "finish",
        component: _35b95e93,
        name: "invoice-index-finish"
      }]
    }, {
      path: "/login",
      component: _1bbf6304,
      name: "login"
    }, {
      path: "/finial/invoice",
      component: _4cf7140e,
      name: "finial-invoice"
    }, {
      path: "/finial/payin",
      component: _d1a598ce,
      name: "finial-payin"
    }, {
      path: "/finial/payout",
      component: _c8eb6fec,
      name: "finial-payout"
    }, {
      path: "/meta/crm",
      component: _6e77a564,
      name: "meta-crm"
    }, {
      path: "/meta/product",
      component: _d7ba4842,
      name: "meta-product"
    }, {
      path: "/meta/user",
      component: _6f18b7ea,
      name: "meta-user"
    }, {
      path: "/options/flowState",
      component: _5dd15820,
      name: "options-flowState"
    }, {
      path: "/options/org",
      component: _ea6f937e,
      name: "options-org"
    }, {
      path: "/options/payType",
      component: _a45a0442,
      name: "options-payType"
    }, {
      path: "/options/pos",
      component: _898dfc9e,
      name: "options-pos"
    }, {
      path: "/options/ptype",
      component: _f54a2272,
      name: "options-ptype"
    }, {
      path: "/options/role",
      component: _729df9e9,
      name: "options-role"
    }, {
      path: "/options/storeNo",
      component: _d7922742,
      name: "options-storeNo"
    }, {
      path: "/options/type",
      component: _5a3206ad,
      name: "options-type"
    }, {
      path: "/order/buy",
      component: _19f0d21a,
      name: "order-buy"
    }, {
      path: "/order/buy-list",
      component: _6f7203e8,
      name: "order-buy-list"
    }, {
      path: "/order/deliver",
      component: _ca6970dc,
      name: "order-deliver"
    }, {
      path: "/order/import-buy",
      component: _b86cc4fe,
      name: "order-import-buy"
    }, {
      path: "/order/import-sale",
      component: _f3ce7748,
      name: "order-import-sale"
    }, {
      path: "/order/order-row",
      component: _b60eddf0,
      name: "order-order-row"
    }, {
      path: "/order/pake-list",
      component: _310cb466,
      name: "order-pake-list"
    }, {
      path: "/order/plane-list",
      component: _5259b212,
      name: "order-plane-list"
    }, {
      path: "/order/sale",
      component: _1e99f92a,
      name: "order-sale"
    }, {
      path: "/order/sale-list",
      component: _47e76c11,
      name: "order-sale-list"
    }, {
      path: "/produce/on",
      component: _093f6c58,
      name: "produce-on"
    }, {
      path: "/store/calc",
      component: _40c45bea,
      name: "store-calc"
    }, {
      path: "/store/calc-list",
      component: _71061060,
      name: "store-calc-list"
    }, {
      path: "/store/collocation",
      component: _3612abef,
      name: "store-collocation"
    }, {
      path: "/store/in",
      component: _4f12674a,
      name: "store-in"
    }, {
      path: "/store/in-buy",
      component: _6485e194,
      name: "store-in-buy"
    }, {
      path: "/store/in-sale",
      component: _4635faae,
      name: "store-in-sale"
    }, {
      path: "/store/out",
      component: _f91870f0,
      name: "store-out"
    }, {
      path: "/store/outsend",
      component: _039ac9e0,
      name: "store-outsend"
    }, {
      path: "/",
      component: _2391bca7,
      name: "index"
    }],

    fallback: false
  })
}
